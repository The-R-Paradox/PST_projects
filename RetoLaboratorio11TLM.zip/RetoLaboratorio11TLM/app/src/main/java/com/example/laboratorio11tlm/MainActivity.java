 package com.example.laboratorio11tlm;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.TableLayout;
import android.widget.TableRow;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

 public class MainActivity extends AppCompatActivity {

    private String server = "192.168.100.37";
    private int port = 8080;
    private TextView consulta;
    private RequestQueue requestQueue;
    private EditText tabla;
    private EditText condicion;

     //
     private TableLayout tl;
     //

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        consulta = (TextView)findViewById(R.id.textView);
        tabla = (EditText)findViewById(R.id.etTabla);
        condicion = (EditText)findViewById(R.id.etCondicion);
        //
        //tl = (TableLayout)findViewById(R.id.tableLayout); *Problema al inicializarlo aquí*
        //
        requestQueue = Volley.newRequestQueue(this);

    }

     public void conectar(View view){
         StringRequest request = new StringRequest(
                 Request.Method.GET,
                 "http://"+server+":"+port+"/android",
                 new Response.Listener<String>() {
                     @Override
                     public void onResponse(String response) {
                         if(response != null)
                             consulta.setText(response);
                         else
                             consulta.setText("Error desconocido en la consulta");
                     }
                 },
                 new Response.ErrorListener() {
                     @Override
                     public void onErrorResponse(VolleyError error) {

                     }
                 }
         );
         requestQueue.add(request);
     }

     public void consultar (View view){
        String query = null;
        String infoTabla = tabla.getText().toString();
        String infoCondicion = condicion.getText().toString();
        if(!infoTabla.isEmpty() || !infoCondicion.isEmpty()){
            if(!infoTabla.isEmpty() && !infoCondicion.isEmpty()){

                query = "Select * From " + infoTabla + " where " + infoCondicion;
            }
            else if(!infoTabla.isEmpty()){
                query = "Select * From " + infoTabla;
            }
            else if(infoCondicion.isEmpty()){
                Toast.makeText(this, "No ha ingresado la tabla de la cual extraer los datos",
                        Toast.LENGTH_SHORT).show();
            }
        }else{
            Toast.makeText(this, "No ha datos para realizar la consulta",
                    Toast.LENGTH_SHORT).show();
        }

         System.out.println(query);

        if(query!=null){

         StringRequest request = new StringRequest(
                 Request.Method.GET,
                 "http://"+server+":"+port+"/android/"+query,
                 new Response.Listener<String>() {
                     @Override
                     public void onResponse(String response) {
                         if(response != null) {
                             //consulta.setText(response);

                             String[] filas = response.split("\n");

                             tl = (TableLayout)findViewById(R.id.tableLayout);

                             //new TableRow(view.getContext());
                             int c = 0;
                             for (String fila : filas){
                                 System.out.println(fila);
                                 if (fila.contains("|")){
                                     TableRow newtr = (TableRow) LayoutInflater.from(view.getContext()).inflate(R.layout.filatablerow, null);
                                     String[] infoFila = fila.replaceAll("\\s+","").split("\\|");
                                     //Eliminar todos los espacios -> .replaceAll("\\s+","")

                                     String id = infoFila[0];
                                     String nombre = infoFila[1];
                                     String apellido = infoFila[2];

                                     System.out.println(id + nombre + apellido);
                                     ((TextView)newtr.findViewById(R.id.textViewId)).setText(id);
                                     ((TextView)newtr.findViewById(R.id.textViewNombre)).setText(nombre);
                                     ((TextView)newtr.findViewById(R.id.textViewApellido)).setText(apellido);
                                     //newtr.addView(textView);
                                     tl.addView(newtr);
                                     c++;
                                 }else{
                                     consulta.setText(consulta.getText() + fila + "\n");
                                 }
                             }
                         }else
                             consulta.setText("Error desconocido en la consulta");
                     }
                 },
                 new Response.ErrorListener() {
                     @Override
                     public void onErrorResponse(VolleyError error) {

                     }
                 }
         );
         requestQueue.add(request);
        }
        else{
            Toast.makeText(this, "Consulta Incorrecta",
                    Toast.LENGTH_SHORT).show();
        }
     }


 }