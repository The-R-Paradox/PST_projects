package data

import android.graphics.drawable.Drawable
import com.example.personal_calculator_by_the_r_paradox.Operation

class DataSource {
    var historialOperaciones = listOf<Operation>()
    fun loadOperation(operation: Operation): List<Operation>{
            historialOperaciones = historialOperaciones.plus(operation)
        return historialOperaciones
    }

}