package com.example.personal_calculator_by_the_r_paradox

data class Operation(val drawableOperation: Int, val stringTitle: String, var stringDetail: String) {
}