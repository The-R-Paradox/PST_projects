package com.example.personal_calculator_by_the_r_paradox

import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import data.DataSource


class MainActivity : AppCompatActivity() {

    var num1:String = ""
    var num2:String = ""
    var operation:String = ""
    var lastChange:String = ""
    var textViewInfo: TextView? = null
    lateinit var myDataSet:List<Operation>
    lateinit var recyclerView:RecyclerView
    var infoPresentar:String = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        textViewInfo = findViewById(R.id.mensajeInicial)

        val newOperationExample = Operation(R.drawable.historial, "Historial", "Aquí aparecen las operaciones que vaya realizando")

        recyclerView = findViewById<RecyclerView>(R.id.recycler_view)

        myDataSet = DataSource().loadOperation(newOperationExample)

        recyclerView.adapter = ItemAdapter(this, myDataSet)


    }

    fun setButtonPressed(v: View) {
        val button:Button = findViewById(v.id)
        val info = button.text.toString()
        println("Botón presionado: $info")

        when(info){

            "DEL"->
            {
                num1 = ""
                num2 = ""
                operation = ""
                infoPresentar = "$num1 $operation $num2"
            }

            "AC" ->
            {
                if(num1!="" || operation!="" || num2!="")
                {
                    when (lastChange) {
                        "num1" -> num1 = num1.subSequence(0, num1.length - 1) as String
                        "operation" -> operation = operation.subSequence(0, operation.length - 1) as String
                        "num2" -> num2 = num2.subSequence(0, num2.length - 1) as String
                    }
                    infoPresentar = "$num1 $operation $num2"
                }
                else{
                    infoPresentar = "No hay nada que borrar"
                }
            }

            else ->
            {
                when(operation){

                    "" ->
                    {
                        if (info != "+" && info != "-" && info != "*"
                            && info != "/" && info != "="){
                            num1 += info
                            lastChange = "num1"
                        } else {
                            operation = info
                            lastChange = "operation"
                        }
                    }
                    else ->
                    {
                        if (info != "+" && info != "-" && info != "*"
                            && info != "/" && info != "="){
                            num2+= info
                            lastChange = "num2"
                        }
                        else{
                            when(info){
                                "+", "-" , "*", "/" -> println("No válido, sino ingresará más dígitos presione =")
                            }
                        }
                    }

                }
                infoPresentar = "$num1 $operation $num2"
            }
        }

        textViewInfo?.text = infoPresentar
    }

    fun calculate(v: View){

        if(num1!="" && num2!="" && operation!="") {
            var resultado: Double = 0.0

            lateinit var newOperation:Operation

            when (operation) {
                "+" ->
                {
                    resultado += num1.toDouble() + num2.toDouble()
                    newOperation = Operation(R.drawable.suma, "SUMA", "")
                }
                "-" ->
                {
                    resultado += num1.toDouble() - num2.toDouble()
                    newOperation = Operation(R.drawable.resta, "RESTA", "")
                }
                "*" ->
                {
                    resultado += num1.toDouble() * num2.toDouble()
                    newOperation = Operation(R.drawable.multiplicacion, "MULTIPLICACIÓN", "")
                }
                "/" ->
                {
                    resultado += num1.toDouble() / num2.toDouble()
                    newOperation = Operation(R.drawable.division, "DIVISIÓN", "")
                }
            }
            println("$num1 $operation $num2 = $resultado")

            infoPresentar = "$num1 $operation $num2 = $resultado"

            newOperation.stringDetail = infoPresentar

            myDataSet = myDataSet + DataSource().loadOperation(newOperation)

            recyclerView.adapter = ItemAdapter(this, myDataSet)
            recyclerView.scrollToPosition(myDataSet.size-1)

        }
        else{
            println("$num1 $operation $num2 = ")
            println("Faltan datos para poder operar")
            infoPresentar = "Faltan datos para poder operar"
        }

        textViewInfo?.text = infoPresentar

        num1 = ""
        num2 = ""
        operation = ""


    }



}
