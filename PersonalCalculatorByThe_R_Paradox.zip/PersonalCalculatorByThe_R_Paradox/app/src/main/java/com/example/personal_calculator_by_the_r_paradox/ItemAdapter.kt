package com.example.personal_calculator_by_the_r_paradox

import android.content.Context
import android.service.autofill.Dataset
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class ItemAdapter(private val context: Context,
                  private val dataset: List<Operation>
                  ):RecyclerView.Adapter<ItemAdapter.ItemViewHolder>() {

    /*
    Otra forma, pero en este caso no se necesita
    var titles = dataset.forEach(){it.stringTitle}
    var details = dataset.forEach(){it.stringDetail}
    var images = dataset.forEach(){it.drawableOperation}
    */


    class ItemViewHolder(private val v:View):RecyclerView.ViewHolder(v){
        val item_title:TextView = v.findViewById(R.id.item_title)
        val item_detail:TextView = v.findViewById(R.id.item_detail)
        val item_image:ImageView = v.findViewById(R.id.item_image)


    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ItemViewHolder {
        var adapterLayout = LayoutInflater.from(parent.context)
            .inflate(R.layout.list_item, parent, false)
        return ItemViewHolder(adapterLayout)
    }

    override fun onBindViewHolder(holder: ItemViewHolder, position: Int) {
        val item = dataset[position]
        holder.item_title.text = item.stringTitle
        holder.item_detail.text = item.stringDetail
        holder.item_image.setImageResource(item.drawableOperation)
    }

    override fun getItemCount(): Int {
        return dataset.size
    }
}